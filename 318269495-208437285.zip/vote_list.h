//
// Created by David on 02/05/2020.
//

#ifndef ELECTION_VOTE_LIST_H
#define ELECTION_VOTE_LIST_H

#include "vote_node.h"

/**
* linked-list for saving votes from a source to a destination.
* The list contains a pointer to the first node associated with it.
*
* Implements a linked-list
*
* The following functions are available:
*   voteListCreate	- Creates a new empty list.
*   voteListDestroy	- Destroys an existing list and frees all associated resources.
*   voteListAdd	- Adds votes from an area(source) to a tribe(destination).
*   voteListRemove	- Removes an area or a map from the list.
*   voteListContainArea	- Returns whether an area exists in the list.
*   voteListFindMaxTribe - Returns the tribe with the highest number of votes from a certain area.
 *   if more than one tribe has the same (highest) amount of votes, then it returns the one with the lowest id.
*/

/*Type for defining the list*/
typedef struct vote_list_t* VoteList;

/*Type used for returning errors from the list*/
typedef enum VoteListResult_t
{
    VOTE_LIST_SUCCESS,
    VOTE_LIST_OUT_OF_MEMORY,
    VOTE_LIST_NULL_ARGUMENT
}VoteListResult;

/*Type used for indicating voteListRemove function whether it needs to remove an area or a tribe*/
typedef enum VoteListRemoveCandidate_t
{
    REMOVE_TRIBE,
    REMOVE_AREA
}VoteListRemoveCandidate;

/**
 * voteListCreate	- Creates a new empty list.
 *
 * @return
 * NULL - if a memory allocation failed.
 * a new voteList otherwise.
 */
VoteList voteListCreate();

/**
 * voteListDestroy	- Destroys an existing list and frees all associated resources.
 *
 * @param list - target list to destroy.
 */
void voteListDestroy(VoteList list);

/**
 * voteListAdd	- Adds votes from an area(source) to a tribe(destination).
 * if the user wants to remove votes, then this function should be used with a negative number of votes.
 * @param list - target list.
 * @param area_id - target area id.
 * @param tribe_id - target tribe id.
 * @param num_of_votes - number of votes to add.
 * @return
 * VOTE_LIST_NULL_ARGUMENT - if list is NULL.
 * VOTE_LIST_OUT_OF_MEMORY - if a memory allocation failed.
 * VOTE_SUCCESS - if votes were added (or removed) properly.
 */
VoteListResult voteListAdd(VoteList list, int area_id, int tribe_id, int num_of_votes);

/**
 *  voteListRemove	- Removes an area or a map from the list.
 * @param list - target list to remove from.
 * @param id - id of area/tribe to be removed
 * @param remove_candidate - flag that indicates whether an area or a tribe should be removed.
 */
void voteListRemove(VoteList list, int id, VoteListRemoveCandidate remove_candidate);

/**
 * voteListContainArea	- Returns whether an area exists in the list.
 * @param list - target list to search in.
 * @param area_id - area id to search for.
 * @return
 * NULL - if the target area wasn't found (doesn't exist in target list).
 * the first node in the list that contains the target area.
 * (the areas are stored in "blocks" in the list, meaning all nodes associated with the same area are stored one
 * after the other.
 */
VoteNode voteListContainArea(VoteList list, int area_id);

/**
 * voteListFindMaxTribe - Returns the tribe with the highest number of votes from a certain area.
 * if more than one tribe has the same (highest) amount of votes, then it returns the one with the lowest id.
 * if in a certain area no votes were assigned to every tribe, then it returns the lowest id among all tribes.
 * @param area - target area to look in.
 * @param tribe_id_minimal - the lowest id among all tribes.
 * @return
 * the id of the tribe with maximum number of votes.
 */
int voteListFindMaxTribe(VoteNode area, int tribe_id_minimal);
#endif //ELECTION_VOTE_LIST_H
