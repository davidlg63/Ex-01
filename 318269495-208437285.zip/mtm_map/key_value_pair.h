//
// Created by David on 01/05/2020.
//

#ifndef KEY_VALUE_PAIR_H
#define KEY_VALUE_PAIR_H
/**
 * implement of a Key_Value_pair container type
 * the type of key and data is char*.
 *
 * the following functions are available:
 *     pairCreate       -creates a new Key_Value_Pair struct and return a pointer to its start.
 *     pairDestroy      - removes the Key_Value_Pair and frees all its allocated memory.
 *     pairGetKey       - returns the value of the key that stored in the related struct.
 *     pairGetData      - returns the value of the data that stored in the related struct.
 *     pairSetData      - changes the value of the data element which is stored in the struct.
 *
 */
typedef struct Key_Value_Pair* Pair;

/** Type used for returning errors from related functions*/
typedef enum key_value_pair_result_t
{
    PAIR_SUCCESS,
    PAIR_OUT_OF_MEMORY,
}PairResult;

/**
 * pairCreate       -creates a new Key_Value_Pair struct and return a pointer to its start. The function will set the
 *                   data and the key to the values given by the user.
 *
 * @param key       - the key value given by the user
 * @param data      - the data value given by the user
 * @return
 * NULL if any of the related memory allocation has failed
 * Pointer to the start of the struct.
 */
Pair pairCreate(const char* key, const char* data);

/**
 * pairDestroy      - removes the Key_Value_Pair and frees all its allocated memory
 *
 * @param pair      - Pointer to the pair that will be freed by the function
 */
void  pairDestroy(Pair pair);

/**
 * pairGetKey       - returns the value of the key that stored in the related struct.
 *
 * @param pair      - Pointer to the struct which the returned key value is stored in
 * @return
 * The key value which stored in the struct
 */
char* pairGetKey(Pair pair);

/**
 * pairGetData       - returns the value of the data that stored in the related struct.
 *
 * @param pair      - Pointer to the struct which the returned data value is stored in
 * @return
 * The data value which stored in the struct
 */
char* pairGetData(Pair pair);

/**
 *   pairSetData      - changes the value of the data element which is stored in the struct.
 *
 * @param pair        - Pointer to the struct whose data value will be changed
 * @param new_data    - The new data element which will replace the existing one
 * @return
 * Pair_OUT_OF_MEMORY if any of the memory allocations has failed
 * PAIR_SUCCESS if the process has succeeded.
 */
PairResult pairSetData(Pair pair, const char* new_data);

#endif /*KEY_VALUE_PAIR_H */
