//
// Created by David on 18/04/2020.
//

#ifndef NODE_H
#define NODE_H

#include "map.h"

/**
* Node type for a maps linked-list
*
* Implements a node for a maps linked-list
*
* The following functions are available:
*   nodeCreate		- Creates a new node that contains a desired key and data pair.
*   nodeRemove		- Removes an existing node and frees all associated resources.
*   nodeGetNext		- Returns the next node after the current node.
*   nodeGetPrevious	- Returns the previous node of the current node.
*   nodeGetKey	- Returns the key of the target node.
*   nodeGetData - Returns the data of the target node.
*   nodeSetData - Changes the data of the target node.
*/

/*Type for defining the node*/
typedef  struct  node_t* Node;

/*Type used for returning errors from the node*/
typedef enum node_result_t
{
    NODE_SUCCESS,
    NODE_OUT_OF_MEMORY,
}NodeResult;

/**
* nodeCreate: Removes an existing node and frees all associated resources.
 *
 * @param last_node - last node of the target map.
 * @param key - The key that should be added to the map.
 * @param data - The key that should be added to the map.
 *
 * @return
 * NULL - if memory allocation failed.
 * The desired node otherwise.
*
*/
Node nodeCreate(Node last_node, const char* key, const char* data);

/**
* nodeRemove: Creates a new node that contains a desired key and data pair.
 * @param node - target node to remove.
*
*/
void nodeRemove(Node node);

/**
* nodeGetNext: Returns the next node after the current node.
 *
 * @param current_node - target node.
 *
 * @return
 * NULL - if current node is NULL.
 * The next node in the list (might be NULL).
*
*/
Node nodeGetNext(Node current_node);

/**
* nodeGetPrevious: Returns the previous node of the current node.
 *
 * @param current_node - target node.
 *
 * @return
 * NULL - if current node is NULL.
 * The previous node in the list (might be NULL).
*
*/
Node nodeGetPrevious(Node current_node);

/**
* nodeGetKey: Returns the key of the target node.
 *
 * @param node - target node.
 *
 * @return
 * NULL - if node is NULL.
 * The key associated with the target node.
*
*/
char* nodeGetKey(Node node);

/**
* nodeGetData: Returns the data of the target node.
 *
 * @param node - target node.
 *
 * @return
 * NULL - if node is NULL.
 * The data associated with the target node.
*
*/
char* nodeGetData(Node node);

/**
* nodeSetData: Changes the data of the target node.
 *
 * @param node - target node.
 * @param new_data - the new data that should be assigned to the target node.
 *
 * @return
 * NODE_OUT_OF_MEMORY - if a memory allocation failed.
 * NODE_SUCCESS - if the data was changed properly.
*
*/
NodeResult nodeSetData(Node node, const char* new_data);

#endif //NODE_H
